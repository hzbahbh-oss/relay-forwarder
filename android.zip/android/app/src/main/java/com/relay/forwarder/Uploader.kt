package com.relay.forwarder

import android.content.Context
import android.util.Log
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Executors

/**
 * Pushes an event to Firestore via the plain REST API.
 * No Firebase SDK / google-services.json required.
 */
object Uploader {

    private val pool = Executors.newSingleThreadExecutor()

    fun deviceName(ctx: Context): String {
        val prefs = ctx.getSharedPreferences("relay", Context.MODE_PRIVATE)
        return prefs.getString("device_name", null) ?: (android.os.Build.MODEL ?: "Phone")
    }

    fun setDeviceName(ctx: Context, name: String) {
        ctx.getSharedPreferences("relay", Context.MODE_PRIVATE)
            .edit().putString("device_name", name).apply()
    }

    /**
     * @param type  "sms" | "call_incoming" | "call_missed" | "call_ended"
     */
    fun send(
        ctx: Context,
        type: String,
        from: String?,
        text: String? = null,
        durationSeconds: Long? = null
    ) {
        val device = deviceName(ctx)
        pool.execute {
            try {
                val fields = JSONObject().apply {
                    put("type", strVal(type))
                    put("ts", tsVal(Date()))
                    if (from != null) put("from", strVal(from))
                    if (text != null) put("text", strVal(text))
                    if (durationSeconds != null) put("duration", intVal(durationSeconds))
                    put("device", strVal(device))
                }
                val body = JSONObject().put("fields", fields).toString()

                val conn = (URL(Config.eventsUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    connectTimeout = 15000
                    readTimeout = 15000
                    setRequestProperty("Content-Type", "application/json")
                }
                conn.outputStream.use { it.write(body.toByteArray()) }
                val code = conn.responseCode
                if (code in 200..299) {
                    Log.i("Relay", "Sent $type from $from")
                } else {
                    val err = conn.errorStream?.bufferedReader()?.readText()
                    Log.e("Relay", "Upload failed ($code): $err")
                }
                conn.disconnect()
            } catch (e: Exception) {
                Log.e("Relay", "Upload error", e)
            }
        }
    }

    private fun strVal(s: String) = JSONObject().put("stringValue", s)
    private fun intVal(n: Long) = JSONObject().put("integerValue", n.toString())
    private fun tsVal(d: Date): JSONObject {
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")
        return JSONObject().put("timestampValue", fmt.format(d))
    }
}
