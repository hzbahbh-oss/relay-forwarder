package com.relay.forwarder

// ============================================================
//  EDIT THESE TWO VALUES  (same Firebase project as the website)
// ------------------------------------------------------------
//  PROJECT_ID : Firebase console → Project settings → Project ID
//  API_KEY    : Firebase console → Project settings → Web API Key
// ============================================================
object Config {
    const val PROJECT_ID = "relay-forwarder"
    const val API_KEY = "AIzaSyBDzSBwI1tKW3m_qg1GGO-2CpWUrSybmIs"

    // Firestore REST endpoint for the "events" collection.
    val eventsUrl: String
        get() = "https://firestore.googleapis.com/v1/projects/$PROJECT_ID/databases/(default)/documents/events?key=$API_KEY"
}
