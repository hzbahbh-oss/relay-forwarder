package com.relay.forwarder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

/** Fires on every incoming SMS, even if the app UI is closed. */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        // A single SMS can arrive as multiple parts — join them by sender.
        val bySender = LinkedHashMap<String, StringBuilder>()
        for (msg in Telephony.Sms.Intents.getMessagesFromIntent(intent)) {
            val from = msg.displayOriginatingAddress ?: "Unknown"
            bySender.getOrPut(from) { StringBuilder() }.append(msg.messageBody ?: "")
        }
        for ((from, body) in bySender) {
            Uploader.send(ctx, type = "sms", from = from, text = body.toString())
        }
    }
}
