package com.relay.forwarder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.CallLog
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

/**
 * Tracks call-state transitions to classify each call.
 *   RINGING                     -> incoming (record number + start time)
 *   RINGING then OFFHOOK        -> answered
 *   RINGING then IDLE (no answer) -> MISSED
 *   OFFHOOK then IDLE           -> call ENDED (with duration)
 *
 * We forward call *metadata* only — live audio can't be streamed from a
 * normal Android phone.
 */
class CallReceiver : BroadcastReceiver() {

    companion object {
        private var lastState = TelephonyManager.CALL_STATE_IDLE
        private var incomingNumber: String? = null
        private var answered = false
        private var callStart = 0L
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return

        val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
        if (!number.isNullOrBlank()) incomingNumber = number

        val stateStr = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
        val state = when (stateStr) {
            TelephonyManager.EXTRA_STATE_RINGING -> TelephonyManager.CALL_STATE_RINGING
            TelephonyManager.EXTRA_STATE_OFFHOOK -> TelephonyManager.CALL_STATE_OFFHOOK
            else -> TelephonyManager.CALL_STATE_IDLE
        }
        if (state == lastState) return

        when (state) {
            TelephonyManager.CALL_STATE_RINGING -> {
                answered = false
                callStart = System.currentTimeMillis()
                Uploader.send(ctx, type = "call_incoming", from = incomingNumber ?: "Unknown")
            }
            TelephonyManager.CALL_STATE_OFFHOOK -> {
                // Ignore outgoing calls: OFFHOOK reached without a preceding RINGING.
                answered = lastState == TelephonyManager.CALL_STATE_RINGING
                if (answered) callStart = System.currentTimeMillis()
            }
            TelephonyManager.CALL_STATE_IDLE -> {
                // On Android 10+ the number can be absent from the broadcast; fall back to the call log.
                val number = incomingNumber ?: lastLoggedNumber(ctx) ?: "Unknown"
                when {
                    lastState == TelephonyManager.CALL_STATE_RINGING && !answered -> {
                        Uploader.send(ctx, type = "call_missed", from = number)
                    }
                    answered -> {
                        val dur = (System.currentTimeMillis() - callStart) / 1000
                        Uploader.send(ctx, type = "call_ended", from = number, durationSeconds = dur)
                    }
                }
                incomingNumber = null
                answered = false
            }
        }
        lastState = state
    }

    /** Reads the most recent call-log entry's number (requires READ_CALL_LOG). */
    private fun lastLoggedNumber(ctx: Context): String? {
        if (ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.READ_CALL_LOG)
            != PackageManager.PERMISSION_GRANTED) return null
        return try {
            ctx.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER),
                null, null,
                "${CallLog.Calls.DATE} DESC"
            )?.use { c ->
                if (c.moveToFirst()) c.getString(0)?.takeIf { it.isNotBlank() } else null
            }
        } catch (e: Exception) { null }
    }
}
