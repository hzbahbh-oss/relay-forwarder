package com.relay.forwarder

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val permissions = buildList {
        add(Manifest.permission.RECEIVE_SMS)
        add(Manifest.permission.READ_PHONE_STATE)
        add(Manifest.permission.READ_CALL_LOG)   // needed so call events include the caller's number
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            add(Manifest.permission.POST_NOTIFICATIONS)
    }.toTypedArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nameField = findViewById<EditText>(R.id.deviceName)
        val status = findViewById<TextView>(R.id.status)
        nameField.setText(Uploader.deviceName(this))

        findViewById<Button>(R.id.saveBtn).setOnClickListener {
            val n = nameField.text.toString().ifBlank { "Phone" }
            Uploader.setDeviceName(this, n)
            Toast.makeText(this, "Device name saved: $n", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.startBtn).setOnClickListener {
            requestPerms()
            startService()
            requestBatteryExemption()
            status.text = "Status: running ✓  (you can close this app)"
        }

        findViewById<Button>(R.id.testBtn).setOnClickListener {
            Uploader.send(this, type = "sms", from = "TEST", text = "Test event from ${Uploader.deviceName(this)}")
            Toast.makeText(this, "Test event sent — check your web dashboard", Toast.LENGTH_LONG).show()
        }

        // Auto-start if permissions already granted.
        if (hasAllPerms()) {
            startService()
            status.text = "Status: running ✓  (you can close this app)"
        }
    }

    private fun hasAllPerms() = permissions.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestPerms() {
        if (!hasAllPerms()) ActivityCompat.requestPermissions(this, permissions, 100)
    }

    private fun startService() {
        val svc = Intent(this, ForwarderService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(svc)
        else startService(svc)
    }

    /** Ask the user to exclude the app from battery optimization -> survives 24/7. */
    private fun requestBatteryExemption() {
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            intent.data = Uri.parse("package:$packageName")
            startActivity(intent)
        } catch (_: Exception) { /* not all devices expose this */ }
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        if (hasAllPerms()) startService()
        else Toast.makeText(this, "All permissions are needed for forwarding to work", Toast.LENGTH_LONG).show()
    }
}
