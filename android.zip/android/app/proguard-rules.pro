# No obfuscation needed for this app. Debug builds don't use this file.
